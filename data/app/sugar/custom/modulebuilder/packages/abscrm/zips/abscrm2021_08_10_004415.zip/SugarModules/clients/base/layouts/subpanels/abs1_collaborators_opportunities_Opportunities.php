<?php
// created: 2021-08-09 23:35:31
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_ABS1_COLLABORATORS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_ABS1_COLLABORATORS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_ABS1_COLLABORATORS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_ABS1_COLLABORATORS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);