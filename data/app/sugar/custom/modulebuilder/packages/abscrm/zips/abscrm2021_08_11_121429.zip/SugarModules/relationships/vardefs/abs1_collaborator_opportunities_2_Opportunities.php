<?php
// created: 2021-08-09 23:41:57
$dictionary["Opportunity"]["fields"]["abs1_collaborator_opportunities_2"] = array (
  'name' => 'abs1_collaborator_opportunities_2',
  'type' => 'link',
  'relationship' => 'abs1_collaborator_opportunities_2',
  'source' => 'non-db',
  'module' => 'ABS1_collaborator',
  'bean_name' => 'ABS1_collaborator',
  'vname' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_2_FROM_ABS1_COLLABORATOR_TITLE',
  'id_name' => 'abs1_collaborator_opportunities_2abs1_collaborator_ida',
);
