<?php
// created: 2021-08-09 23:37:01
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_2_FROM_ABS1_COLLABORATOR_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborator_opportunities_2',
  ),
);