<?php
// created: 2021-08-11 11:29:24
$viewdefs['Contacts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_IDENTIFICATIONS_CONTACTS_FROM_ABS1_IDENTIFICATIONS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_identifications_contacts',
  ),
);