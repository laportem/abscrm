<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Ομάδες',
  'LBL_TEAMS' => 'Ομάδες',
  'LBL_TEAM_ID' => 'Ταυτότητα Ομάδας',
  'LBL_ASSIGNED_TO_ID' => 'Ταυτότητα Ανατεθειμένου Χρήστη',
  'LBL_ASSIGNED_TO_NAME' => 'Ανατέθηκε σε',
  'LBL_TAGS_LINK' => 'Ετικέτες',
  'LBL_TAGS' => 'Ετικέτες',
  'LBL_ID' => 'Ταυτότητα',
  'LBL_DATE_ENTERED' => 'Ημερομηνία Δημιουργίας',
  'LBL_DATE_MODIFIED' => 'Ημερομηνία Τροποποίησης',
  'LBL_MODIFIED' => 'Τροποποιήθηκε Από',
  'LBL_MODIFIED_ID' => 'Τροποποιήθηκε Από Ταυτότητα',
  'LBL_MODIFIED_NAME' => 'Τροποποιήθηκε Από Όνομα',
  'LBL_CREATED' => 'Δημιουργήθηκε Από',
  'LBL_CREATED_ID' => 'Δημιουργήθηκε Από Ταυτότητα',
  'LBL_DOC_OWNER' => 'Κάτοχος του εγγράφου',
  'LBL_USER_FAVORITES' => 'Αγαπημένα Χρηστών',
  'LBL_DESCRIPTION' => 'Περιγραφή',
  'LBL_DELETED' => 'Διαγράφηκε',
  'LBL_NAME' => 'Όνομα',
  'LBL_CREATED_USER' => 'Δημιουργήθηκε Από Χρήστη',
  'LBL_MODIFIED_USER' => 'Τροποποιήθηκε από Χρήστη',
  'LBL_LIST_NAME' => 'Όνομα',
  'LBL_EDIT_BUTTON' => 'Επεξεργασία',
  'LBL_REMOVE' => 'Αφαίρεση',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Τροποποιήθηκε Από Όνομα',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Δημιουργήθηκε με όνομα',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Providers Λίστα',
  'LBL_MODULE_NAME' => 'Providers',
  'LBL_MODULE_TITLE' => 'Providers',
  'LBL_MODULE_NAME_SINGULAR' => 'Provider',
  'LBL_HOMEPAGE_TITLE' => 'Δική Μου Providers',
  'LNK_NEW_RECORD' => 'Δημιουργία Provider',
  'LNK_LIST' => 'Προβολή Providers',
  'LNK_IMPORT_ABS1_PROVIDERS' => 'Import Providers',
  'LBL_SEARCH_FORM_TITLE' => 'Αναζήτηση Provider',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Προβολή Ιστορικού',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Δραστηριότητες',
  'LBL_ABS1_PROVIDERS_SUBPANEL_TITLE' => 'Providers',
  'LBL_NEW_FORM_TITLE' => 'Νέα Provider',
  'LNK_IMPORT_VCARD' => 'Import Provider vCard',
  'LBL_IMPORT' => 'Import Providers',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Provider record by importing a vCard from your file system.',
  'LBL_ABS1_PROVIDERS_FOCUS_DRAWER_DASHBOARD' => 'Providers Focus Drawer',
  'LBL_ABS1_PROVIDERS_RECORD_DASHBOARD' => 'Providers Record Dashboard',
  'LBL_PROVIDER_TYPE' => 'Type',
  'LBL_CONTACT' => 'Contact',
  'LBL_ORGANISATION' => 'Organisation',
  'LBL_MAT_C' => 'MAT',
  'LBL_CONTACT_CONTACT_ID' => 'Contact (related Contact ID)',
  'LBL_ACCOUNT_ACCOUNT_ID' => 'Organisation (related Organisation ID)',
  'LBL_ACCOUNT' => 'Organisation',
  'LBL_UUID_C' => 'UUID',
);