<?php
// created: 2021-08-11 11:29:24
$dictionary["Opportunity"]["fields"]["abs1_sponsors_opportunities"] = array (
  'name' => 'abs1_sponsors_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_sponsors_opportunities',
  'source' => 'non-db',
  'module' => 'ABS1_sponsors',
  'bean_name' => 'ABS1_sponsors',
  'vname' => 'LBL_ABS1_SPONSORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'abs1_sponsors_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
