<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favourite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Created By Name',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Providers List',
  'LBL_MODULE_NAME' => 'Providers',
  'LBL_MODULE_TITLE' => 'Providers',
  'LBL_MODULE_NAME_SINGULAR' => 'Provider',
  'LBL_HOMEPAGE_TITLE' => 'My Providers',
  'LNK_NEW_RECORD' => 'Create Provider',
  'LNK_LIST' => 'View Providers',
  'LNK_IMPORT_ABS1_PROVIDERS' => 'Import Providers',
  'LBL_SEARCH_FORM_TITLE' => 'Search Provider',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_ABS1_PROVIDERS_SUBPANEL_TITLE' => 'Providers',
  'LBL_NEW_FORM_TITLE' => 'New Provider',
  'LNK_IMPORT_VCARD' => 'Import Provider vCard',
  'LBL_IMPORT' => 'Import Providers',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Provider record by importing a vCard from your file system.',
  'LBL_ABS1_PROVIDERS_FOCUS_DRAWER_DASHBOARD' => 'Providers Focus Drawer',
  'LBL_ABS1_PROVIDERS_RECORD_DASHBOARD' => 'Providers Record Dashboard',
  'LBL_PROVIDER_TYPE' => 'Type',
  'LBL_CONTACT' => 'Contact',
  'LBL_ORGANISATION' => 'Organisation',
  'LBL_MAT_C' => 'MAT',
  'LBL_CONTACT_CONTACT_ID' => 'Contact (related Contact ID)',
  'LBL_ACCOUNT_ACCOUNT_ID' => 'Organisation (related Organisation ID)',
  'LBL_ACCOUNT' => 'Organisation',
  'LBL_UUID_C' => 'UUID',
);