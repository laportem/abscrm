<?php
// created: 2021-08-14 22:46:57
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_PROJECTMEMBERS_OPPORTUNITIES_FROM_ABS1_PROJECTMEMBERS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_projectmembers_opportunities',
  ),
);