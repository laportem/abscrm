<?php
// created: 2021-08-09 23:41:57
$dictionary["Opportunity"]["fields"]["abs1_collaborator_opportunities_1"] = array (
  'name' => 'abs1_collaborator_opportunities_1',
  'type' => 'link',
  'relationship' => 'abs1_collaborator_opportunities_1',
  'source' => 'non-db',
  'module' => 'ABS1_collaborator',
  'bean_name' => 'ABS1_collaborator',
  'vname' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_1_FROM_ABS1_COLLABORATOR_TITLE',
  'id_name' => 'abs1_collaborator_opportunities_1abs1_collaborator_ida',
);
