<?php
// created: 2021-08-11 11:29:24
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_PROVIDERS_OPPORTUNITIES_FROM_ABS1_PROVIDERS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_providers_opportunities',
  ),
);

$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_PROVIDERS_OPPORTUNITIES_FROM_ABS1_PROVIDERS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_providers_opportunities',
  ),
);

$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_PROVIDERS_OPPORTUNITIES_FROM_ABS1_PROVIDERS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_providers_opportunities',
  ),
);

$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_PROVIDERS_OPPORTUNITIES_FROM_ABS1_PROVIDERS_TITLE',
  'context' => 
  array (
    'link' => 'abs1_providers_opportunities',
  ),
);