<?php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$dictionary['ABS1_resources'] = array(
    'table' => 'abs1_resources',
    'audited' => true,
    'activity_enabled' => false,
    'duplicate_merge' => true,
    'fields' => array (
  'resource_type' => 
  array (
    'required' => true,
    'readonly' => false,
    'name' => 'resource_type',
    'vname' => 'LBL_RESOURCE_TYPE',
    'type' => 'varchar',
    'massupdate' => true,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => true,
    'reportable' => true,
    'unified_search' => true,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => true,
      'boost' => '1',
      'searchable' => true,
    ),
    'calculated' => false,
    'len' => '255',
    'size' => '20',
  ),
  'family' => 
  array (
    'required' => true,
    'readonly' => false,
    'name' => 'family',
    'vname' => 'LBL_FAMILY',
    'type' => 'text',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => true,
    'unified_search' => true,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => true,
      'boost' => '1',
      'searchable' => true,
    ),
    'calculated' => false,
    'size' => '20',
    'studio' => 'visible',
    'rows' => '3',
    'cols' => '20',
  ),
  'resource_parts' => 
  array (
    'required' => true,
    'readonly' => false,
    'name' => 'resource_parts',
    'vname' => 'LBL_RESOURCE_PARTS',
    'type' => 'text',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => true,
    'unified_search' => true,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => true,
      'boost' => '1',
      'searchable' => true,
    ),
    'calculated' => false,
    'size' => '20',
    'studio' => 'visible',
    'rows' => '3',
    'cols' => '20',
  ),
  'specimens' => 
  array (
    'required' => true,
    'readonly' => false,
    'name' => 'specimens',
    'vname' => 'LBL_SPECIMENS',
    'type' => 'text',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => true,
    'unified_search' => true,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => true,
      'boost' => '1',
      'searchable' => true,
    ),
    'calculated' => false,
    'size' => '20',
    'studio' => 'visible',
    'rows' => '3',
    'cols' => '20',
  ),
  'collection_area' => 
  array (
    'required' => false,
    'readonly' => false,
    'name' => 'collection_area',
    'vname' => 'LBL_COLLECTION_AREA',
    'type' => 'text',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => '0',
      'boost' => '1',
      'searchable' => false,
    ),
    'calculated' => false,
    'size' => '20',
    'studio' => 'visible',
    'rows' => '4',
    'cols' => '20',
  ),
  'uuid_c' => 
  array (
    'required' => false,
    'readonly' => false,
    'name' => 'uuid_c',
    'vname' => 'LBL_UUID_C',
    'type' => 'varchar',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => false,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => '',
    'full_text_search' => 
    array (
      'enabled' => '0',
      'boost' => '1',
      'searchable' => false,
    ),
    'calculated' => false,
    'len' => '255',
    'size' => '20',
  ),
),
    'relationships' => array (
),
    'optimistic_locking' => true,
    'unified_search' => true,
    'full_text_search' => true,
);

if (!class_exists('VardefManager')){
}
VardefManager::createVardef('ABS1_resources','ABS1_resources', array('basic','team_security','assignable','taggable'));