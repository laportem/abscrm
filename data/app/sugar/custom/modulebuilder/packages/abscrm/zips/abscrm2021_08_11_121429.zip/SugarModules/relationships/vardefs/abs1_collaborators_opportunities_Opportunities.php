<?php
// created: 2021-08-11 12:14:29
$dictionary["Opportunity"]["fields"]["abs1_collaborators_opportunities"] = array (
  'name' => 'abs1_collaborators_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_collaborators_opportunities',
  'source' => 'non-db',
  'module' => 'ABS1_collaborators',
  'bean_name' => 'ABS1_collaborators',
  'vname' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'abs1_collaborators_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
