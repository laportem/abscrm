<?php
 // created: 2021-08-11 12:05:00
$layout_defs["Accounts"]["subpanel_setup"]['abs1_identifications_accounts'] = array (
  'order' => 100,
  'module' => 'ABS1_identifications',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ABS1_IDENTIFICATIONS_ACCOUNTS_FROM_ABS1_IDENTIFICATIONS_TITLE',
  'get_subpanel_data' => 'abs1_identifications_accounts',
);
