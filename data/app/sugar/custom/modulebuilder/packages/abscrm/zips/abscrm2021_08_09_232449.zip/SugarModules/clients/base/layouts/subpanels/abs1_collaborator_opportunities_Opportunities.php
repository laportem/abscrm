<?php
// created: 2021-08-09 22:46:06
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_ABS1_COLLABORATOR_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborator_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_ABS1_COLLABORATOR_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborator_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_ABS1_COLLABORATOR_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborator_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_ABS1_COLLABORATOR_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborator_opportunities',
  ),
);