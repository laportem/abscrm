<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Tiimit',
  'LBL_TEAMS' => 'Tiimit',
  'LBL_TEAM_ID' => 'Tiimin tunnus',
  'LBL_ASSIGNED_TO_ID' => 'Vastuukäyttäjän ID',
  'LBL_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
  'LBL_TAGS_LINK' => 'Tagit',
  'LBL_TAGS' => 'Tagit',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Luontipäivä',
  'LBL_DATE_MODIFIED' => 'Muokkattu viimeksi',
  'LBL_MODIFIED' => 'Muokannut',
  'LBL_MODIFIED_ID' => 'Muokkaajan ID',
  'LBL_MODIFIED_NAME' => 'Muokkaajan nimi',
  'LBL_CREATED' => 'Luonut',
  'LBL_CREATED_ID' => 'Luojan ID',
  'LBL_DOC_OWNER' => 'Tiedoston omistaja',
  'LBL_USER_FAVORITES' => 'Käyttäjät, jotka ottivat suosikikseen',
  'LBL_DESCRIPTION' => 'Kuvaus',
  'LBL_DELETED' => 'Poistettu',
  'LBL_NAME' => 'Nimi',
  'LBL_CREATED_USER' => 'Luoja',
  'LBL_MODIFIED_USER' => 'Muokkaaja',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_EDIT_BUTTON' => 'Muokkaa',
  'LBL_REMOVE' => 'Poista',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Muokkaajan nimi',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Luojan nimi',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Project Members Lista',
  'LBL_MODULE_NAME' => 'Project Members',
  'LBL_MODULE_TITLE' => 'Project Members',
  'LBL_MODULE_NAME_SINGULAR' => 'Project Member',
  'LBL_HOMEPAGE_TITLE' => 'Oma Project Members',
  'LNK_NEW_RECORD' => 'Luo Project Member',
  'LNK_LIST' => 'Näkymä Project Members',
  'LNK_IMPORT_ABS1_PROJECTMEMBERS' => 'Import Project Members',
  'LBL_SEARCH_FORM_TITLE' => 'Etsi Project Member',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Näytä historia',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_ABS1_PROJECTMEMBERS_SUBPANEL_TITLE' => 'Project Members',
  'LBL_NEW_FORM_TITLE' => 'Uusi Project Member',
  'LNK_IMPORT_VCARD' => 'Import Project Member vCard',
  'LBL_IMPORT' => 'Import Project Members',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Project Member record by importing a vCard from your file system.',
  'LBL_ABS1_PROJECTMEMBERS_FOCUS_DRAWER_DASHBOARD' => 'Project Members Focus Drawer',
  'LBL_ABS1_PROJECTMEMBERS_RECORD_DASHBOARD' => 'Project Members Record Dashboard',
  'LBL_CONTACT_BUG_ID' => 'Contact (related Bug ID)',
  'LBL_CONTACT' => 'Contact',
  'LBL_PROJECT_ROLE' => 'Project Role',
);