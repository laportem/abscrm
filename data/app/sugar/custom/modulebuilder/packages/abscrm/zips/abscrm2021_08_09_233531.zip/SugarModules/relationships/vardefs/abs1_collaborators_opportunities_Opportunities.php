<?php
// created: 2021-08-09 23:35:31
$dictionary["Opportunity"]["fields"]["abs1_collaborators_opportunities"] = array (
  'name' => 'abs1_collaborators_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_collaborators_opportunities',
  'source' => 'non-db',
  'module' => 'ABS1_collaborators',
  'bean_name' => false,
  'vname' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_ABS1_COLLABORATORS_TITLE',
  'id_name' => 'abs1_collaborators_opportunitiesabs1_collaborators_ida',
);
