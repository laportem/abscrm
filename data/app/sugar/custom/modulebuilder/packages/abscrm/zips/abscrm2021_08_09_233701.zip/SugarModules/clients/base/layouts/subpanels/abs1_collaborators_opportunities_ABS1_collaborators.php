<?php
// created: 2021-08-09 23:35:31
$viewdefs['ABS1_collaborators']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);

$viewdefs['ABS1_collaborators']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'abs1_collaborators_opportunities',
  ),
);