<?php
 // created: 2021-08-09 23:35:31
$layout_defs["ABS1_collaborators"]["subpanel_setup"]['abs1_collaborators_opportunities'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'abs1_collaborators_opportunities',
);
