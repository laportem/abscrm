<?php
// created: 2021-08-09 23:41:57
$dictionary["ABS1_collaborators"]["fields"]["abs1_collaborators_opportunities"] = array (
  'name' => 'abs1_collaborators_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_collaborators_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_ABS1_COLLABORATORS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'abs1_collaborators_opportunitiesopportunities_idb',
);
