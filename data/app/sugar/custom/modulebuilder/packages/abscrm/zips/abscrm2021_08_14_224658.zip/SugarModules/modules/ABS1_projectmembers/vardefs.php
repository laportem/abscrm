<?php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$dictionary['ABS1_projectmembers'] = array(
    'table' => 'abs1_projectmembers',
    'audited' => true,
    'activity_enabled' => false,
    'duplicate_merge' => true,
    'fields' => array (
  'bug_id_c' => 
  array (
    'required' => false,
    'readonly' => false,
    'name' => 'bug_id_c',
    'vname' => 'LBL_CONTACT_BUG_ID',
    'type' => 'id',
    'massupdate' => false,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => 1,
    'audited' => false,
    'reportable' => false,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'pii' => false,
    'calculated' => false,
    'len' => 36,
    'size' => '20',
  ),
  'contact' => 
  array (
    'required' => true,
    'readonly' => false,
    'source' => 'non-db',
    'name' => 'contact',
    'vname' => 'LBL_CONTACT',
    'type' => 'relate',
    'massupdate' => true,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => false,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'pii' => false,
    'calculated' => false,
    'len' => 255,
    'size' => '20',
    'id_name' => 'bug_id_c',
    'ext2' => 'Bugs',
    'module' => 'Bugs',
    'rname' => 'name',
    'quicksearch' => 'enabled',
    'studio' => 'visible',
  ),
  'project_role' => 
  array (
    'required' => true,
    'readonly' => false,
    'name' => 'project_role',
    'vname' => 'LBL_PROJECT_ROLE',
    'type' => 'enum',
    'massupdate' => true,
    'hidemassupdate' => false,
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'enabled',
    'duplicate_merge_dom_value' => '1',
    'audited' => true,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'pii' => false,
    'default' => 'Passport',
    'calculated' => false,
    'len' => 100,
    'size' => '20',
    'options' => 'abs_Identification_type_list',
    'dependency' => false,
  ),
),
    'relationships' => array (
),
    'optimistic_locking' => true,
    'unified_search' => true,
    'full_text_search' => true,
);

if (!class_exists('VardefManager')){
}
VardefManager::createVardef('ABS1_projectmembers','ABS1_projectmembers', array('basic','team_security','assignable','taggable'));