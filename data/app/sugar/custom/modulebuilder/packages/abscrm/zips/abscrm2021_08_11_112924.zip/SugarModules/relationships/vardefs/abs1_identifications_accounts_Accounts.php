<?php
// created: 2021-08-11 11:29:24
$dictionary["Account"]["fields"]["abs1_identifications_accounts"] = array (
  'name' => 'abs1_identifications_accounts',
  'type' => 'link',
  'relationship' => 'abs1_identifications_accounts',
  'source' => 'non-db',
  'module' => 'ABS1_identifications',
  'bean_name' => false,
  'vname' => 'LBL_ABS1_IDENTIFICATIONS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'abs1_identifications_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
