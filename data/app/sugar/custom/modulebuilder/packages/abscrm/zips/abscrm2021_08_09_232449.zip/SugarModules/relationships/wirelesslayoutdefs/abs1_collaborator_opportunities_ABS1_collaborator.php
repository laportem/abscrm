<?php
 // created: 2021-08-09 23:24:49
$layout_defs["ABS1_collaborator"]["subpanel_setup"]['abs1_collaborator_opportunities'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'abs1_collaborator_opportunities',
);
