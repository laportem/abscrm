<?php
// created: 2021-08-11 12:14:29
$dictionary["Opportunity"]["fields"]["abs1_providers_opportunities"] = array (
  'name' => 'abs1_providers_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_providers_opportunities',
  'source' => 'non-db',
  'module' => 'ABS1_providers',
  'bean_name' => 'ABS1_providers',
  'vname' => 'LBL_ABS1_PROVIDERS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'abs1_providers_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
