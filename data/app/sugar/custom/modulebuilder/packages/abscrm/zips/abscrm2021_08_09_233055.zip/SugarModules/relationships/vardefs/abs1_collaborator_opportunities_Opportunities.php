<?php
// created: 2021-08-09 23:30:55
$dictionary["Opportunity"]["fields"]["abs1_collaborator_opportunities"] = array (
  'name' => 'abs1_collaborator_opportunities',
  'type' => 'link',
  'relationship' => 'abs1_collaborator_opportunities',
  'source' => 'non-db',
  'module' => 'ABS1_collaborator',
  'bean_name' => 'ABS1_collaborator',
  'vname' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_FROM_ABS1_COLLABORATOR_TITLE',
  'id_name' => 'abs1_collaborator_opportunitiesabs1_collaborator_ida',
);
