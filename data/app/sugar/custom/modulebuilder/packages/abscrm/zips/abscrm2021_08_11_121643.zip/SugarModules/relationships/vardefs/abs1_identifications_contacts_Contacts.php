<?php
// created: 2021-08-11 12:16:42
$dictionary["Contact"]["fields"]["abs1_identifications_contacts"] = array (
  'name' => 'abs1_identifications_contacts',
  'type' => 'link',
  'relationship' => 'abs1_identifications_contacts',
  'source' => 'non-db',
  'module' => 'ABS1_identifications',
  'bean_name' => 'ABS1_identifications',
  'vname' => 'LBL_ABS1_IDENTIFICATIONS_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'abs1_identifications_contactscontacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
