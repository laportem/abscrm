<?php
// created: 2021-08-09 23:41:57
$dictionary["ABS1_collaborator"]["fields"]["abs1_collaborator_opportunities_1"] = array (
  'name' => 'abs1_collaborator_opportunities_1',
  'type' => 'link',
  'relationship' => 'abs1_collaborator_opportunities_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_ABS1_COLLABORATOR_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'abs1_collaborator_opportunities_1opportunities_idb',
);
